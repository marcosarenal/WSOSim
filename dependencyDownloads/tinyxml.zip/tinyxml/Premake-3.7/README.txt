PREMAKE
Build Script Generation

Copyright (C) 2002-2008 by Jason Perkins
Distributed under the GNU General Public License, see LICENSE.txt

The Lua language and runtime library is (C) TeCGraf, PUC-Rio.
See their website at http://www.lua.org/


BUILDING PREMAKE

  GNU make: type 'make' (also Cygwin and MinGW)

  MS Visual C++ 6: open Premake.dsw and build.

  MS Visual C++ 2002-2008: open Premake.sln and build.


For questions, comments, or more information, visit the project
website at http://premake.sourceforge.net/
